# Demo Download — CMS-2025-0240

This file is a demonstration download for docket CMS-2025-0240.

The data contained in this package is a pre-prepared sample provided for 
demonstration purposes only.

When the full download feature is live, requesting this docket will 
automatically fetch all associated documents and comments directly from 
regulations.gov, zip them, and deliver them to you as a complete and 
up-to-date package.

Thank you for your patience as we continue to develop this feature.